const AWS = require('aws-sdk');

exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    
    try {
        const s3 = new AWS.S3();
        let key = 'index.html';
        
        if (event.pathParameters && event.pathParameters.proxy) {
            key = event.pathParameters.proxy;
        }
        
        const result = await s3.getObject({
            Bucket: 'faceid-auth-1730092800',
            Key: key
        }).promise();
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': key.endsWith('.js') ? 'application/javascript' : 'text/html',
                'Access-Control-Allow-Origin': '*'
            },
            body: result.Body.toString()
        };
        
    } catch (error) {
        console.error('Error:', error);
        
        // If file not found, serve index.html
        if (error.code === 'NoSuchKey') {
            try {
                const s3 = new AWS.S3();
                const result = await s3.getObject({
                    Bucket: 'faceid-auth-1730092800',
                    Key: 'index.html'
                }).promise();
                
                return {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'text/html',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: result.Body.toString()
                };
            } catch (indexError) {
                return {
                    statusCode: 500,
                    headers: { 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: 'Error loading page' })
                };
            }
        }
        
        return {
            statusCode: 500,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
};

